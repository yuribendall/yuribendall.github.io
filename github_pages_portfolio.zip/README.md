# Yuri — Materials Science & Mechatronic Systems Portfolio

A fluid, editorial, multi-page engineering portfolio designed for GitHub Pages.

## Structure
- `index.html`: Complete portfolio featuring:
  - **Home / Landing Page**: Hero banner, latest work highlights, core skills across Materials, Mechanical, Electrical & Systems, and direct contact section.
  - **Work Index**: Reverse-chronological archive (2026–2022) with discipline filtering.
  - **Individual Project Pages**: Dedicated case-study view for all 8 projects with wide hero banners, metadata strips, systems-coupling breakdowns, secondary visual documentation galleries, and long-form engineering field notes.
  - **About Page**: Full narrative (*Who I Am*, *What I Have Done*, *What I Want to Do & Why*) and reverse-chronological timeline.
- `assets/`: High-resolution project and studio imagery.

## Deploying to Your Existing GitHub Pages Repository
1. Copy `index.html` and the `assets/` folder into the root of your GitHub Pages repository.
2. Keep your existing `CNAME` file untouched so your custom domain and HTTPS configuration remain active.
3. Commit and push:
   ```bash
   git add index.html assets/
   git commit -m "Update portfolio to fluid editorial multi-page design"
   git push
   ```
